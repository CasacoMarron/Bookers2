# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '846aca08ee19a997e444e337b3e32e81a98d44980c45e9ca167c8d204a5658c81307dd51af4ab57d2161f36a1b27858efcc8f5128c5b1444b4138e5a615642cb'